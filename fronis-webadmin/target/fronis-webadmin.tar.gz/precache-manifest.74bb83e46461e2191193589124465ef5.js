self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2a6e771ed50c02a758b419c2c33f31d5",
    "url": "/admin/index.html"
  },
  {
    "revision": "8f9e01b3258f94a3e241",
    "url": "/admin/static/css/main.5ecd60fb.chunk.css"
  },
  {
    "revision": "8addd560b202669fb05b",
    "url": "/admin/static/js/2.74530b07.chunk.js"
  },
  {
    "revision": "f07796f4f30300629a9fa688e41af979",
    "url": "/admin/static/js/2.74530b07.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8f9e01b3258f94a3e241",
    "url": "/admin/static/js/main.1a03d82f.chunk.js"
  },
  {
    "revision": "cc221527bb1cfa7cdb10",
    "url": "/admin/static/js/runtime-main.23f47d80.js"
  }
]);